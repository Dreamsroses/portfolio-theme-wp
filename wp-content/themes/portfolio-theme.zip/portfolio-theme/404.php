<?php get_header() ?>

	<h1>Error 404:</h1>
	<h2>Página no encontrada</h2>

<?php get_footer() ?>